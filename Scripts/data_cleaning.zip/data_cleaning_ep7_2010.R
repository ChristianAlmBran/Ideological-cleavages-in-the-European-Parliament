# Loading packages
pacman::p_load(readxl, openxlsx, lubridate, tidyverse)

# Loading files
## CHES
ches_original <- read.csv(r"(/Users/chrisalmbran/Library/CloudStorage/Box-Box/Phd/Artigos/Artigo - ABCP 2.0/ches/1999-2019_CHES_dataset_means(v3).csv)")

## VoteWatch
### EP7 - 2009-2014
ep7_rcvs_original <- read_excel(r"(/Users/chrisalmbran/Library/CloudStorage/Box-Box/Phd/Artigos/Artigo - ABCP 2.0/votewatch/EP7_RCVs_2014_06_19.xlsx)")

ep7_voted_original <- read_excel(r"(/Users/chrisalmbran/Library/CloudStorage/Box-Box/Phd/Artigos/Artigo - ABCP 2.0/votewatch/EP7_Voted docs.xlsx)")

## national_party_names_index_all_eps
national_party_names_index_all_eps <- read_excel('national_party_names_index_all_eps.xlsx')

# Making the national_party_names_index_all_eps file
## This file is being prepared on excel with information form the three datasets
## used in the article: CHES, VoterWatch, and HowTheyVoted
party_names_ep7 <- ep7_rcvs_original %>%
  select(Country, Party) %>%
  distinct()

# CHES 
## Selecting/Filtering columns/rows of interest
ches_ep7 <- ches_original %>%
  filter(year %in% c(2010, 2014), eumember == 1) %>%
  select(year, party_id, eu_position, lrecon, galtan)

# VoteWatch
## EP 7
### Selecting/Filtering columns/rows of interest and only final votes
ep7_rcvs_mod <- ep7_rcvs_original %>%
  select(-Fname, -Lname, -EPG)

ep7_voted_mod <- ep7_voted_original %>%
  select(`Vote ID`, Date, Title, Procedure, `Leg/Non-Leg/Bud`, `Type of Vote`, 
         `Voting Rule`, `interinstitutional file number`, De, `Final vote?`, Vote)

#ep7_voted_mod <- ep7_voted_original %>%
#  select(`Vote ID`, Date, Title, Procedure, `Leg/Non-Leg/Bud`, `Type of Vote`, 
#         `Voting Rule`, `interinstitutional file number`, De, `Final vote?`, Vote) %>%
#  filter(`Final vote?` == 1)

# Merging the national parties index with MEP info
##EP7
ep7_rcvs_mod <- ep7_rcvs_mod %>%
  left_join(national_party_names_index_all_eps %>% select(Party_Name_VoterWatch_EP7,
                                                          Country_VoterWatch, Party_ID), 
            by = c("Party" = "Party_Name_VoterWatch_EP7", "Country" = "Country_VoterWatch"))

### Rearrange the columns to place Party_ID next to Party
ep7_rcvs_mod <- ep7_rcvs_mod %>%
  select(`MEP ID`, FullName, Country, Party, Party_ID, everything())

# Adding information about the ideology of the national parties
ep7_rcvs_ideology_2010 <- ep7_rcvs_mod %>%
  left_join(ches_ep7 %>% filter(year == 2010), by = c("Party_ID" = "party_id"))

## Rearrange the columns to place the ideologies next to Party_ID
ep7_rcvs_ideology_2010 <- ep7_rcvs_ideology_2010 %>%
  select(`MEP ID`, FullName, Country, Party, Party_ID, eu_position, lrecon, galtan, everything())

## Filtering rows with independents and non-CHES parties
### We do not have information on 147 MEP, reducing the MEPs from 950 to 803
ep7_rcvs_ideology_2010 <- ep7_rcvs_ideology_2010 %>%
  drop_na(Party_ID)

# Filtering for the policy area: Environmental and Public health
## I will need to filter further manually to keep only environmentally related votes
## This will be done with information from the EP website
ep7_voted_env_public_health <- ep7_voted_mod %>%
  filter(De == "Environment & public health")

## Exporting the df to Excel, to create a new column and make the manual verification
write.xlsx(ep7_voted_env_public_health, "ep7_voted_env_public_health.xlsx")

## Loading edited df
ep7_voted_env <- read_excel("ep7_voted_env_public_health_marked_all_votes.xlsx")

## Merging with the main df
ep7_voted_env <- ep7_voted_mod %>%
  left_join(ep7_voted_env %>% select(`Vote ID`, environment_only), by = "Vote ID")

## Replacing the NAs with no
ep7_voted_env <- ep7_voted_env %>%
  mutate(environment_only = replace_na(environment_only, "no"))

# Adding underscores to improve readability, removing spaces and special characters
ep7_voted_env <- ep7_voted_env %>%
  rename(vote_id = `Vote ID`, date = Date, title = Title, procedure = Procedure,
         type_of_vote = `Type of Vote`, voting_rule = `Voting Rule`, 
         interinstitutional_file_number = `interinstitutional file number`,
         committee_responsabile = `De`, final_vote = `Final vote?`, vote = `Vote`)

# Filtering to keep only environmental votes
#ep7_voted_env <- ep7_voted_env %>%
#  filter(environment_only == 'yes')

# Re-scaling the eu_position columns to make it comparable with the other ideologies
# eu_position: 1 to 7, others: 0 to 10
ep7_rcvs_ideology_2010$eu_position <- (ep7_rcvs_ideology_2010$eu_position - 1) * (5 / 3)

# Changing the rcvs data sets from wide format to long
ep7_rcvs_ideology_2010_long <- ep7_rcvs_ideology_2010 %>%
  pivot_longer(cols = matches("^\\d+$"), 
               names_to = "vote_id", 
               values_to = "voting_outcome")

ep7_rcvs_ideology_2010_long$vote_id <- as.double(ep7_rcvs_ideology_2010_long$vote_id)

# Joining the dfs, so all the information is in one place
joined_ep7_2010 <- ep7_rcvs_ideology_2010_long %>%
  inner_join(ep7_voted_env, by = "vote_id")

# Filtering for votes for or against
joined_ep7_2010 <- joined_ep7_2010 %>%
  filter(voting_outcome == 1 | voting_outcome == 2)

# Changing against votes from 2 to 0 for the binomial regression
## yes = 1; no = 0
joined_ep7_2010 <- joined_ep7_2010 %>%
  mutate(voting_outcome = ifelse(voting_outcome == 2, 0, voting_outcome))

# Creating a new df to preserve the old one
joined_ep7_inverted_2010 <- joined_ep7_2010

# Rounding the CHES variables to 2 digits
joined_ep7_inverted_2010$lrecon <- round(joined_ep7_inverted_2010$lrecon, digits = 2)
joined_ep7_inverted_2010$galtan <- round(joined_ep7_inverted_2010$galtan, digits = 2)
joined_ep7_inverted_2010$eu_position <- round(joined_ep7_inverted_2010$eu_position, digits = 2)

# Removing NAs
joined_ep7_inverted_2010 <- joined_ep7_inverted_2010 %>%
  filter(!is.na(lrecon) & !is.na(galtan) & !is.na(eu_position))

#joined_ep7_inverted_2010_leg <- joined_ep7_inverted_2010 %>%
#  filter(`Leg/Non-Leg/Bud` == "Leg")


# Step 1: Count the number of votes against (voting_outcome == 0) per vote_id
votes_against_per_vote <- table(joined_ep7_inverted_2010$vote_id[joined_ep7_inverted_2010$voting_outcome == 0])

# Step 2: Find vote_ids where there are less than 33 votes against
votes_to_remove <- names(votes_against_per_vote[votes_against_per_vote < 33])

# Step 3: Filter out rows where the vote_id is in the list of votes to remove
joined_ep7_inverted_2010_filtered <- joined_ep7_inverted_2010[!joined_ep7_inverted_2010$vote_id %in% votes_to_remove, ]


# EP7
## Fitting the logistic regression models for each vote
vote_models <- lapply(unique(joined_ep7_inverted_2010_filtered$vote_id), function(vote_id_val) {
  subset_data <- subset(joined_ep7_inverted_2010_filtered, vote_id == vote_id_val)
  model <- glm(voting_outcome ~ lrecon + galtan + eu_position, data = subset_data, family = binomial,
               control = glm.control(maxit = 100))
  return(model)
})

## Extracting coefficients and determine directions
coefs <- lapply(vote_models, function(model) {
  coef_direction <- sapply(model$coefficients, function(coef) {
    ifelse(coef > 0, 1, 0)
  })
  return(coef_direction)
})

## Creating new columns with directions
joined_ep7_inverted_2010_filtered$direction_lrgen <- rep(NA, nrow(joined_ep7_inverted_2010_filtered))
joined_ep7_inverted_2010_filtered$direction_galtan <- rep(NA, nrow(joined_ep7_inverted_2010_filtered))
joined_ep7_inverted_2010_filtered$direction_eu_position <- rep(NA, nrow(joined_ep7_inverted_2010_filtered))

for (i in 1:length(vote_models)) {
  vote <- unique(joined_ep7_inverted_2010_filtered$vote_id)[i]
  joined_ep7_inverted_2010_filtered[joined_ep7_inverted_2010_filtered$vote_id == vote, "direction_lrgen"] <- coefs[[i]]["lrecon"]
  joined_ep7_inverted_2010_filtered[joined_ep7_inverted_2010_filtered$vote_id == vote, "direction_galtan"] <- coefs[[i]]["galtan"]
  joined_ep7_inverted_2010_filtered[joined_ep7_inverted_2010_filtered$vote_id == vote, "direction_eu_position"] <- coefs[[i]]["eu_position"]
}

# Adding the inverted columns
# EP7
## Copying the df
ep7_inverted_mod <- joined_ep7_inverted_2010_filtered

# Add columns with initial values (NA or 0)
ep7_inverted_mod$true_vote_lrgen <- rep(NA, nrow(ep7_inverted_mod))
ep7_inverted_mod$true_vote_galtan <- rep(NA, nrow(ep7_inverted_mod))
ep7_inverted_mod$true_vote_eu_position <- rep(NA, nrow(ep7_inverted_mod))

# Updating true vote based on conditions
ep7_inverted_mod <- ep7_inverted_mod %>%
  mutate(true_vote_lrgen = case_when(
    voting_outcome == 1 & direction_lrgen == 0 ~ 0,
    voting_outcome == 0 & direction_lrgen == 0 ~ 1,
    voting_outcome == 0 & direction_lrgen == 1 ~ 0,
    TRUE ~ 1  # Default case (else)
  ))
ep7_inverted_mod <- ep7_inverted_mod %>%
  mutate(true_vote_galtan = case_when(
    voting_outcome == 1 & direction_galtan == 0 ~ 0,
    voting_outcome == 0 & direction_galtan == 0 ~ 1,
    voting_outcome == 0 & direction_galtan == 1 ~ 0,
    TRUE ~ 1  # Default case (else)
  ))
ep7_inverted_mod <- ep7_inverted_mod %>%
  mutate(true_vote_eu_position = case_when(
    voting_outcome == 1 & direction_eu_position == 0 ~ 0,
    voting_outcome == 0 & direction_eu_position == 0 ~ 1,
    voting_outcome == 0 & direction_eu_position == 1 ~ 0,
    TRUE ~ 1  # Default case (else)
  ))

# Updating the eu_position so that 1 becomes anti eu and 0 pro eu
ep7_inverted_mod <- ep7_inverted_mod %>%
  mutate(true_vote_eu_position = ifelse(true_vote_eu_position == 1, 0, 1))

# Selecting the columns of interest
ep7_mlr <- ep7_inverted_mod %>%
  select(`MEP ID`, eu_position, lrecon, galtan, vote_id, procedure, `Leg/Non-Leg/Bud`, final_vote, environment_only, true_vote_lrgen, true_vote_galtan, true_vote_eu_position)

# Fixing a mistake in the dataset, some observations in the final_vote column were coded as 2, when they
# were coded as 2, when they should have been coded as 0
ep7_mlr <- ep7_mlr %>%
  mutate(final_vote = ifelse(final_vote == 2, 0, final_vote))

# Checking the NA observation in the df
ep7_mlr_na_final_vote <- ep7_mlr %>%
  filter(is.na(final_vote))

## Changing the NA to a final vote (1) - the information was checked on the EP website
ep7_mlr <- ep7_mlr %>%
  mutate(final_vote = ifelse(is.na(final_vote), 1, final_vote))

## Exporting the df as csv
write.csv(ep7_mlr, "ep7_mlr.csv", row.names = FALSE, fileEncoding = "UTF-8")
