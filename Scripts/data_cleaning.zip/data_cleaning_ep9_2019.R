# Loading packages
pacman::p_load(readxl, openxlsx, lubridate, tidyverse)

# Loading files
## CHES
ches_original <- read.csv(r"(/Users/chrisalmbran/Library/CloudStorage/Box-Box/Phd/Artigos/Artigo - ABCP 2.0/ches/1999-2019_CHES_dataset_means(v3).csv)")

## VoteWatch
### EP9 - 2019-2024
ep9_rcvs_original <- read_excel(r"(/Users/chrisalmbran/Library/CloudStorage/Box-Box/Phd/Artigos/Artigo - ABCP 2.0/votewatch/EP9_RCVs_2022_06_22.xlsx)")

ep9_voted_original <- read_excel(r"(/Users/chrisalmbran/Library/CloudStorage/Box-Box/Phd/Artigos/Artigo - ABCP 2.0/votewatch/EP9_Voted docs.xlsx)")

## HowTheyVoted
ep9_voted_htv_original <- read.csv(r"(/Users/chrisalmbran/Library/CloudStorage/Box-Box/Phd/Artigos/Artigo - ABCP 2.0/howtheyvoted/votes.csv)")
ep9_members_votes_htv_original <- read.csv(r"(/Users/chrisalmbran/Library/CloudStorage/Box-Box/Phd/Artigos/Artigo - ABCP 2.0/howtheyvoted/member_votes.csv)")
ep9_votes_htv_original <- read.csv(r"(/Users/chrisalmbran/Library/CloudStorage/Box-Box/Phd/Artigos/Artigo - ABCP 2.0/howtheyvoted/votes.csv)")

## national_party_names_index_all_eps
national_party_names_index_all_eps <- read_excel('national_party_names_index_all_eps.xlsx')

# Making the national_party_names_index_all_eps file
## This file is being prepared on excel with information form the three datasets
## used in the article: CHES, VoterWatch, and HowTheyVoted
party_names_ep9 <- ep9_rcvs_original %>%
  select(Country, Party) %>%
  distinct()

# CHES 
## Selecting/Filtering columns/rows of interest
ches_ep9 <- ches_original %>%
  filter(year %in% c(2019), eumember == 1) %>%
  select(year, party_id, eu_position, lrecon, galtan)

# VoteWatch
## EP 8
### Selecting/Filtering columns/rows of interest and only final votes
ep9_rcvs_mod <- ep9_rcvs_original %>%
  select(-Fname, -Lname, -FullName, -EPG)

ep9_voted_mod <- ep9_voted_original %>%
  select(`Vote ID`, Date, Title, Procedure, `Leg/Non-Leg/Bud`, `Type of Vote`, 
         `Voting Rule`, `Interinstitutional file number`, `Policy area`, `Final vote?`, Vote)

### Standardizing the columns names (following the EP7)
ep9_rcvs_mod <- ep9_rcvs_mod %>%
  rename(`MEP ID` = WebisteEpID)

ep9_voted_mod <- ep9_voted_mod %>%
  rename(De = `Policy area`, `interinstitutional file number` = `Interinstitutional file number`)

# Adding the national parties index with MEP info
##EP9
party_names_ep9_party_id <- read_excel('party_names_ep9_party_id.xlsx')

ep9_rcvs_mod <- ep9_rcvs_mod %>%
  left_join(party_names_ep9_party_id, by = c("Party" = "Party", "Country" = "Country"))

### Rearrange the columns to place Party_ID next to Party
ep9_rcvs_mod <- ep9_rcvs_mod %>%
  select(`MEP ID`, Country, Party, Party_ID, everything())

# Adding information about the ideology of the national parties
ep9_rcvs_ideology_2019 <- ep9_rcvs_mod %>%
  left_join(ches_ep9 %>% filter(year == 2019), by = c("Party_ID" = "party_id"))

## Rearrange the columns to place the ideologies next to Party_ID
ep9_rcvs_ideology_2019 <- ep9_rcvs_ideology_2019 %>%
  select(`MEP ID`, Country, Party, Party_ID, eu_position, lrecon, galtan, everything())

## Filtering rows with independents and non-CHES parties
### We do not have information on 147 MEP, reducing the MEPs from 950 to 803
ep9_rcvs_ideology_2019 <- ep9_rcvs_ideology_2019 %>%
  drop_na(Party_ID)

# Filtering for the policy area: Environmental and Public health
## I will need to filter further manually to keep only environmentally related votes
## This will be done with information from the EP website
ep9_voted_env_public_health <- ep9_voted_mod %>%
  filter(De == "Environment & public health")

## Exporting the df to Excel, to create a new column and make the manual verification
write.xlsx(ep9_voted_env_public_health, "ep9_voted_env_public_health.xlsx")

## Loading edited df
ep9_voted_env <- read_excel("ep9_voted_env_public_health_marked_all_votes.xlsx")

## Merging with the main df
ep9_voted_env <- ep9_voted_mod %>%
  left_join(ep9_voted_env %>% select(`Vote ID`, environment_only), by = "Vote ID")

## Replacing the NAs with no
ep9_voted_env <- ep9_voted_env %>%
  mutate(environment_only = replace_na(environment_only, "no"))

# Adding underscores to improve readability, removing spaces and special characters
ep9_voted_env <- ep9_voted_env %>%
  rename(vote_id = `Vote ID`, date = Date, title = Title, procedure = Procedure,
         type_of_vote = `Type of Vote`, voting_rule = `Voting Rule`, 
         interinstitutional_file_number = `interinstitutional file number`,
         committee_responsabile = `De`, final_vote = `Final vote?`, vote = `Vote`)

# Filtering to keep only environmental votes
#ep7_voted_env <- ep7_voted_env %>%
#  filter(environment_only == 'yes')

# Re-scaling the eu_position columns to make it comparable with the other ideologies
# eu_position: 1 to 7, others: 0 to 10
ep9_rcvs_ideology_2019$eu_position <- (ep9_rcvs_ideology_2019$eu_position - 1) * (5 / 3)

# Changing the rcvs data sets from wide format to long
ep9_rcvs_ideology_2019 <- ep9_rcvs_ideology_2019 %>%
  pivot_longer(cols = matches("^\\d+$"), 
               names_to = "vote_id", 
               values_to = "voting_outcome")

ep9_rcvs_ideology_2019$vote_id <- as.double(ep9_rcvs_ideology_2019$vote_id)

# Joining the dfs, so all the information is in one place
joined_ep9_2019 <- ep9_rcvs_ideology_2019 %>%
  inner_join(ep9_voted_env, by = "vote_id")

# Filtering for votes for or against
joined_ep9_2019 <- joined_ep9_2019 %>%
  filter(voting_outcome == 1 | voting_outcome == 2)

# Changing against votes from 2 to 0 for the binomial regression
## yes = 1; no = 0
joined_ep9_2019 <- joined_ep9_2019 %>%
  mutate(voting_outcome = ifelse(voting_outcome == 2, 0, voting_outcome))

# Creating a new df to preserve the old one
joined_ep9_inverted_2019 <- joined_ep9_2019

# Rounding the CHES variables to 2 digits
joined_ep9_inverted_2019$lrecon <- round(joined_ep9_inverted_2019$lrecon, digits = 2)
joined_ep9_inverted_2019$galtan <- round(joined_ep9_inverted_2019$galtan, digits = 2)
joined_ep9_inverted_2019$eu_position <- round(joined_ep9_inverted_2019$eu_position, digits = 2)

# Removing NAs
joined_ep9_inverted_2019 <- joined_ep9_inverted_2019 %>%
  filter(!is.na(lrecon) & !is.na(galtan) & !is.na(eu_position))

#joined_ep7_inverted_2010_leg <- joined_ep7_inverted_2010 %>%
#  filter(`Leg/Non-Leg/Bud` == "Leg")


# Step 1: Count the number of votes against (voting_outcome == 0) per vote_id
votes_against_per_vote <- table(joined_ep9_inverted_2019$vote_id[joined_ep9_inverted_2019$voting_outcome == 0])

# Step 2: Find vote_ids where there are less than 33 votes against
votes_to_remove <- names(votes_against_per_vote[votes_against_per_vote < 33])

# Step 3: Filter out rows where the vote_id is in the list of votes to remove
joined_ep9_inverted_2019_filtered <- joined_ep9_inverted_2019[!joined_ep9_inverted_2019$vote_id %in% votes_to_remove, ]


# EP7
## Fitting the logistic regression models for each vote
vote_models <- lapply(unique(joined_ep9_inverted_2019_filtered$vote_id), function(vote_id_val) {
  subset_data <- subset(joined_ep9_inverted_2019_filtered, vote_id == vote_id_val)
  model <- glm(voting_outcome ~ lrecon + galtan + eu_position, data = subset_data, family = binomial,
               control = glm.control(maxit = 100))
  return(model)
})

## Extracting coefficients and determine directions
coefs <- lapply(vote_models, function(model) {
  coef_direction <- sapply(model$coefficients, function(coef) {
    ifelse(coef > 0, 1, 0)
  })
  return(coef_direction)
})

## Creating new columns with directions
joined_ep9_inverted_2019_filtered$direction_lrgen <- rep(NA, nrow(joined_ep9_inverted_2019_filtered))
joined_ep9_inverted_2019_filtered$direction_galtan <- rep(NA, nrow(joined_ep9_inverted_2019_filtered))
joined_ep9_inverted_2019_filtered$direction_eu_position <- rep(NA, nrow(joined_ep9_inverted_2019_filtered))

for (i in 1:length(vote_models)) {
  vote <- unique(joined_ep9_inverted_2019_filtered$vote_id)[i]
  joined_ep9_inverted_2019_filtered[joined_ep9_inverted_2019_filtered$vote_id == vote, "direction_lrgen"] <- coefs[[i]]["lrecon"]
  joined_ep9_inverted_2019_filtered[joined_ep9_inverted_2019_filtered$vote_id == vote, "direction_galtan"] <- coefs[[i]]["galtan"]
  joined_ep9_inverted_2019_filtered[joined_ep9_inverted_2019_filtered$vote_id == vote, "direction_eu_position"] <- coefs[[i]]["eu_position"]
}

# Adding the inverted columns
# EP7
## Copying the df
ep9_inverted_mod <- joined_ep9_inverted_2019_filtered

# Add columns with initial values (NA or 0)
ep9_inverted_mod$true_vote_lrgen <- rep(NA, nrow(ep9_inverted_mod))
ep9_inverted_mod$true_vote_galtan <- rep(NA, nrow(ep9_inverted_mod))
ep9_inverted_mod$true_vote_eu_position <- rep(NA, nrow(ep9_inverted_mod))

# Updating true vote based on conditions
ep9_inverted_mod <- ep9_inverted_mod %>%
  mutate(true_vote_lrgen = case_when(
    voting_outcome == 1 & direction_lrgen == 0 ~ 0,
    voting_outcome == 0 & direction_lrgen == 0 ~ 1,
    voting_outcome == 0 & direction_lrgen == 1 ~ 0,
    TRUE ~ 1  # Default case (else)
  ))
ep9_inverted_mod <- ep9_inverted_mod %>%
  mutate(true_vote_galtan = case_when(
    voting_outcome == 1 & direction_galtan == 0 ~ 0,
    voting_outcome == 0 & direction_galtan == 0 ~ 1,
    voting_outcome == 0 & direction_galtan == 1 ~ 0,
    TRUE ~ 1  # Default case (else)
  ))
ep9_inverted_mod <- ep9_inverted_mod %>%
  mutate(true_vote_eu_position = case_when(
    voting_outcome == 1 & direction_eu_position == 0 ~ 0,
    voting_outcome == 0 & direction_eu_position == 0 ~ 1,
    voting_outcome == 0 & direction_eu_position == 1 ~ 0,
    TRUE ~ 1  # Default case (else)
  ))

# Updating the eu_position so that 1 becomes anti eu and 0 pro eu
ep9_inverted_mod <- ep9_inverted_mod %>%
  mutate(true_vote_eu_position = ifelse(true_vote_eu_position == 1, 0, 1))

# Selecting the columns of interest
ep9_mlr <- ep9_inverted_mod %>%
  select(`MEP ID`, eu_position, lrecon, galtan, vote_id, procedure, `Leg/Non-Leg/Bud`, final_vote, environment_only, true_vote_lrgen, true_vote_galtan, true_vote_eu_position)

# Fixing a mistake in the dataset, some observations in the final_vote column were coded as 2, when they
# were coded as 2, when they should have been coded as 0
ep9_mlr <- ep9_mlr %>%
  mutate(final_vote = ifelse(final_vote == 2, 0, final_vote))

# Checking the NA observation in the df
ep9_mlr_na_final_vote <- ep9_mlr %>%
  filter(is.na(final_vote))

## Changing the NA to a final vote (1) - the information was checked on the EP website
ep9_mlr <- ep9_mlr %>%
  mutate(final_vote = ifelse(is.na(final_vote), 1, final_vote))

## Exporting the df as csv
write.csv(ep9_mlr, "ep9_mlr.csv", row.names = FALSE, fileEncoding = "UTF-8")
