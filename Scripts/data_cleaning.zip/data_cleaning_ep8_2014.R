# Loading packages
pacman::p_load(readxl, openxlsx, lubridate, tidyverse)

# Loading files
## CHES
ches_original <- read.csv(r"(/Users/chrisalmbran/Library/CloudStorage/Box-Box/Phd/Artigos/Artigo - ABCP 2.0/ches/1999-2019_CHES_dataset_means(v3).csv)")

## VoteWatch
### EP8 - 2014-2019
ep8_rcvs_original <- read_excel(r"(/Users/chrisalmbran/Library/CloudStorage/Box-Box/Phd/Artigos/Artigo - ABCP 2.0/votewatch/EP8_RCVs_2019_06_25.xlsx)")

ep8_voted_original <- read_excel(r"(/Users/chrisalmbran/Library/CloudStorage/Box-Box/Phd/Artigos/Artigo - ABCP 2.0/votewatch/EP8_Voted docs.xlsx)")

## national_party_names_index_all_eps
national_party_names_index_all_eps <- read_excel('national_party_names_index_all_eps.xlsx')

# Making the national_party_names_index_all_eps file
## This file is being prepared on excel with information form the three datasets
## used in the article: CHES, VoterWatch, and HowTheyVoted
party_names_ep8 <- ep8_rcvs_original %>%
  select(Country, Party) %>%
  distinct()

# CHES 
## Selecting/Filtering columns/rows of interest
ches_ep8 <- ches_original %>%
  filter(year %in% c(2014), eumember == 1) %>%
  select(year, party_id, eu_position, lrecon, galtan)

# VoteWatch
## EP 8
### Selecting/Filtering columns/rows of interest and only final votes
ep8_rcvs_mod <- ep8_rcvs_original %>%
  select(-Fname, -Lname, -EPG, -Activ)

ep8_voted_mod <- ep8_voted_original %>%
  select(`Vote ID`, Date, Title, Procedure, `Leg/Non-Leg/Bud`, `Type of Vote`, 
         `Voting Rule`, `interinstitutional file number`, `De/Policy area`, `Final \r\nvote?`, Vote)

### Standardizing the columns names (following the EP7)
ep8_rcvs_mod <- ep8_rcvs_mod %>%
  rename(`MEP ID` = WebisteEpID)

ep8_voted_mod <- ep8_voted_mod %>%
  rename(De = `De/Policy area`, `Final vote?` = `Final \r\nvote?`)

# Merging the national parties index with MEP info
##EP8
ep8_rcvs_mod <- ep8_rcvs_mod %>%
  left_join(national_party_names_index_all_eps %>% select(Party_Name_VoterWatch_EP8,
                                                          Country_VoterWatch, Party_ID), 
            by = c("Party" = "Party_Name_VoterWatch_EP8", "Country" = "Country_VoterWatch"))

### Rearrange the columns to place Party_ID next to Party
ep8_rcvs_mod <- ep8_rcvs_mod %>%
  select(`MEP ID`, Country, Party, Party_ID, everything())

# Adding information about the ideology of the national parties
ep8_rcvs_ideology_2014 <- ep8_rcvs_mod %>%
  left_join(ches_ep8 %>% filter(year == 2014), by = c("Party_ID" = "party_id"))

## Rearrange the columns to place the ideologies next to Party_ID
ep8_rcvs_ideology_2014 <- ep8_rcvs_ideology_2014 %>%
  select(`MEP ID`, Country, Party, Party_ID, eu_position, lrecon, galtan, everything())

## Filtering rows with independents and non-CHES parties
### We do not have information on 147 MEP, reducing the MEPs from 950 to 803
ep8_rcvs_ideology_2014 <- ep8_rcvs_ideology_2014 %>%
  drop_na(Party_ID)

# Filtering for the policy area: Environmental and Public health
## I will need to filter further manually to keep only environmentally related votes
## This will be done with information from the EP website
ep8_voted_env_public_health <- ep8_voted_mod %>%
  filter(De == "Environment & public health")

## Exporting the df to Excel, to create a new column and make the manual verification
write.xlsx(ep8_voted_env_public_health, "ep8_voted_env_public_health.xlsx")

## Loading edited df
ep8_voted_env <- read_excel("ep8_voted_env_public_health_marked_all_votes.xlsx")

## Merging with the main df
ep8_voted_env <- ep8_voted_mod %>%
  left_join(ep8_voted_env %>% select(`Vote ID`, environment_only), by = "Vote ID")

## Replacing the NAs with no
ep8_voted_env <- ep8_voted_env %>%
  mutate(environment_only = replace_na(environment_only, "no"))

# Adding underscores to improve readability, removing spaces and special characters
ep8_voted_env <- ep8_voted_env %>%
  rename(vote_id = `Vote ID`, date = Date, title = Title, procedure = Procedure,
         type_of_vote = `Type of Vote`, voting_rule = `Voting Rule`, 
         interinstitutional_file_number = `interinstitutional file number`,
         committee_responsabile = `De`, final_vote = `Final vote?`, vote = `Vote`)

# Filtering to keep only environmental votes
#ep7_voted_env <- ep7_voted_env %>%
#  filter(environment_only == 'yes')

# Re-scaling the eu_position columns to make it comparable with the other ideologies
# eu_position: 1 to 7, others: 0 to 10
ep8_rcvs_ideology_2014$eu_position <- (ep8_rcvs_ideology_2014$eu_position - 1) * (5 / 3)

# Changing the rcvs data sets from wide format to long
ep8_rcvs_ideology_2014_long <- ep8_rcvs_ideology_2014 %>%
  pivot_longer(cols = matches("^\\d+$"), 
               names_to = "vote_id", 
               values_to = "voting_outcome")

ep8_rcvs_ideology_2014_long$vote_id <- as.double(ep8_rcvs_ideology_2014_long$vote_id)

# Joining the dfs, so all the information is in one place
joined_ep8_2014 <- ep8_rcvs_ideology_2014_long %>%
  inner_join(ep8_voted_env, by = "vote_id")

# Filtering for votes for or against
joined_ep8_2014 <- joined_ep8_2014 %>%
  filter(voting_outcome == 1 | voting_outcome == 2)

# Changing against votes from 2 to 0 for the binomial regression
## yes = 1; no = 0
joined_ep8_2014 <- joined_ep8_2014 %>%
  mutate(voting_outcome = ifelse(voting_outcome == 2, 0, voting_outcome))

# Creating a new df to preserve the old one
joined_ep8_inverted_2014 <- joined_ep8_2014

# Rounding the CHES variables to 2 digits
joined_ep8_inverted_2014$lrecon <- round(joined_ep8_inverted_2014$lrecon, digits = 2)
joined_ep8_inverted_2014$galtan <- round(joined_ep8_inverted_2014$galtan, digits = 2)
joined_ep8_inverted_2014$eu_position <- round(joined_ep8_inverted_2014$eu_position, digits = 2)

# Removing NAs
joined_ep8_inverted_2014 <- joined_ep8_inverted_2014 %>%
  filter(!is.na(lrecon) & !is.na(galtan) & !is.na(eu_position))

#joined_ep7_inverted_2010_leg <- joined_ep7_inverted_2010 %>%
#  filter(`Leg/Non-Leg/Bud` == "Leg")


# Step 1: Count the number of votes against (voting_outcome == 0) per vote_id
votes_against_per_vote <- table(joined_ep8_inverted_2014$vote_id[joined_ep8_inverted_2014$voting_outcome == 0])

# Step 2: Find vote_ids where there are less than 33 votes against
votes_to_remove <- names(votes_against_per_vote[votes_against_per_vote < 33])

# Step 3: Filter out rows where the vote_id is in the list of votes to remove
joined_ep8_inverted_2014_filtered <- joined_ep8_inverted_2014[!joined_ep8_inverted_2014$vote_id %in% votes_to_remove, ]


# EP8
## Fitting the logistic regression models for each vote
vote_models <- lapply(unique(joined_ep8_inverted_2014_filtered$vote_id), function(vote_id_val) {
  subset_data <- subset(joined_ep8_inverted_2014_filtered, vote_id == vote_id_val)
  model <- glm(voting_outcome ~ lrecon + galtan + eu_position, data = subset_data, family = binomial,
               control = glm.control(maxit = 100))
  return(model)
})

## Extracting coefficients and determine directions
coefs <- lapply(vote_models, function(model) {
  coef_direction <- sapply(model$coefficients, function(coef) {
    ifelse(coef > 0, 1, 0)
  })
  return(coef_direction)
})

## Creating new columns with directions
joined_ep8_inverted_2014_filtered$direction_lrgen <- rep(NA, nrow(joined_ep8_inverted_2014_filtered))
joined_ep8_inverted_2014_filtered$direction_galtan <- rep(NA, nrow(joined_ep8_inverted_2014_filtered))
joined_ep8_inverted_2014_filtered$direction_eu_position <- rep(NA, nrow(joined_ep8_inverted_2014_filtered))

for (i in 1:length(vote_models)) {
  vote <- unique(joined_ep8_inverted_2014_filtered$vote_id)[i]
  joined_ep8_inverted_2014_filtered[joined_ep8_inverted_2014_filtered$vote_id == vote, "direction_lrgen"] <- coefs[[i]]["lrecon"]
  joined_ep8_inverted_2014_filtered[joined_ep8_inverted_2014_filtered$vote_id == vote, "direction_galtan"] <- coefs[[i]]["galtan"]
  joined_ep8_inverted_2014_filtered[joined_ep8_inverted_2014_filtered$vote_id == vote, "direction_eu_position"] <- coefs[[i]]["eu_position"]
}

# Adding the inverted columns
## Copying the df
ep8_inverted_mod <- joined_ep8_inverted_2014_filtered

# Add columns with initial values (NA or 0)
ep8_inverted_mod$true_vote_lrgen <- rep(NA, nrow(ep8_inverted_mod))
ep8_inverted_mod$true_vote_galtan <- rep(NA, nrow(ep8_inverted_mod))
ep8_inverted_mod$true_vote_eu_position <- rep(NA, nrow(ep8_inverted_mod))

# Updating true vote based on conditions
ep8_inverted_mod <- ep8_inverted_mod %>%
  mutate(true_vote_lrgen = case_when(
    voting_outcome == 1 & direction_lrgen == 0 ~ 0,
    voting_outcome == 0 & direction_lrgen == 0 ~ 1,
    voting_outcome == 0 & direction_lrgen == 1 ~ 0,
    TRUE ~ 1  # Default case (else)
  ))
ep8_inverted_mod <- ep8_inverted_mod %>%
  mutate(true_vote_galtan = case_when(
    voting_outcome == 1 & direction_galtan == 0 ~ 0,
    voting_outcome == 0 & direction_galtan == 0 ~ 1,
    voting_outcome == 0 & direction_galtan == 1 ~ 0,
    TRUE ~ 1  # Default case (else)
  ))
ep8_inverted_mod <- ep8_inverted_mod %>%
  mutate(true_vote_eu_position = case_when(
    voting_outcome == 1 & direction_eu_position == 0 ~ 0,
    voting_outcome == 0 & direction_eu_position == 0 ~ 1,
    voting_outcome == 0 & direction_eu_position == 1 ~ 0,
    TRUE ~ 1  # Default case (else)
  ))

# Updating the eu_position so that 1 becomes anti eu and 0 pro eu
ep8_inverted_mod <- ep8_inverted_mod %>%
  mutate(true_vote_eu_position = ifelse(true_vote_eu_position == 1, 0, 1))

# Selecting the columns of interest
ep8_mlr <- ep8_inverted_mod %>%
  select(`MEP ID`, eu_position, lrecon, galtan, vote_id, procedure, `Leg/Non-Leg/Bud`, final_vote, environment_only, true_vote_lrgen, true_vote_galtan, true_vote_eu_position)

# Fixing a mistake in the dataset, some observations in the final_vote column were coded as 2, when they
# were coded as 2, when they should have been coded as 0
#ep8_mlr <- ep8_mlr %>%
#  mutate(final_vote = ifelse(final_vote == 2, 0, final_vote))

# Checking the NA observation in the df
ep8_mlr_na_final_vote <- ep8_mlr %>%
  filter(is.na(final_vote))

## Changing the NA to a final vote (1) - the information was checked on the EP website
#ep7_mlr <- ep7_mlr %>%
#  mutate(final_vote = ifelse(is.na(final_vote), 1, final_vote))

## Exporting the df as csv
write.csv(ep8_mlr, "ep8_mlr.csv", row.names = FALSE, fileEncoding = "UTF-8")
