# Loading the packages
pacman::p_load(brms, performance, glmmTMB, tidyverse)

## Loading edited df
ep7_mlr <- read.csv("ep7_mlr.csv")

# mlr
# Converting necessary columns to appropriate types with labels and levels
ep7_mlr$procedure <- factor(ep7_mlr$procedure)

ep7_mlr$Leg.Non.Leg.Bud <- factor(ep7_mlr$Leg.Non.Leg.Bud)

ep7_mlr$final_vote <- factor(ep7_mlr$final_vote)

ep7_mlr$environment_only <- factor(ep7_mlr$environment_only)

ep7_mlr$vote_id <- factor(ep7_mlr$vote_id)

ep7_mlr$MEP.ID <- factor(ep7_mlr$MEP.ID)

# Sample ----
# Set a seed for reproducibility
set.seed(136)

# Step 1: Identify vote_id groups with at least 215 (33%) unique MEPs
valid_votes <- ep7_mlr %>%
  group_by(vote_id) %>%
  filter(n_distinct(MEP.ID) >= 215) %>%
  ungroup() %>%
  distinct(vote_id)

# Step 2: Sample 1128 (20%) vote_id groups from the filtered set
sampled_groups <- valid_votes %>%
  sample_n(1128)

# Step 3: Filter the original dataframe to include only the sampled vote_id groups
filtered_df <- ep7_mlr %>%
  filter(vote_id %in% sampled_groups$vote_id)

# Step 4: Sample 215 observations within each vote_id
ep7_mlr_sample <- filtered_df %>%
  group_by(vote_id) %>%
  sample_n(215) %>%
  ungroup()

# Display the sampled dataframe
print(ep7_mlr_sample)
summary(ep7_mlr)
summary(ep7_mlr_sample)

# Fixing column name error
ep7_mlr_sample <- ep7_mlr_sample %>%
  rename(true_vote_lrecon = true_vote_lrgen)

# Model eu_position ----
# Fit the model on the stratified sample
eu_position_glmmtmb_sample <- glmmTMB(true_vote_eu_position ~ 
                                        lrecon * (environment_only + final_vote) +
                                        eu_position * (environment_only + final_vote) +
                                        galtan * (environment_only + final_vote) +
                                        lrecon * environment_only +
                                        eu_position * environment_only +
                                        galtan * environment_only +
                                        (1 | MEP.ID) +
                                        (1 | vote_id),
                                      data = ep7_mlr_sample,
                                      family = binomial())

check_collinearity(eu_position_glmmtmb_sample)

# 10% mean ----
#YES FINAL VOTE & ENVIRONMENT ONLY ----
mean_quartiles <- function(x) {
  sorted_x <- sort(x)
  n <- length(sorted_x)
  lower_10_mean <- mean(sorted_x[1:floor(n * 0.10)])
  upper_10_mean <- mean(sorted_x[ceiling(n * 0.90):n])
  return(c(lower_10_mean, upper_10_mean))
}

# Define the extreme values for eu_position (eu_position_ep7_environment)
eu_position_quartiles <- mean_quartiles(ep7_mlr_sample$eu_position)
eu_position_ep7_environment_extreme_values <- data.frame(
  eu_position = eu_position_quartiles,
  environment_only = "yes", # or other relevant value
  final_vote = "1", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  lrecon = mean(ep7_mlr_sample$lrecon),
  galtan = mean(ep7_mlr_sample$galtan)
)

# Generate predicted probabilities
predictions <- predict(eu_position_glmmtmb_sample, newdata = eu_position_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[1] - predictions[2]

# Generate the summary
summary_glmmtmb <- summary(eu_position_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond
se_eu_position <- fixed_effects["eu_position", "Std. Error"]

# Extract the variance-covariance matrix
vcov_matrix <- vcov(eu_position_glmmtmb_sample)$cond

# Extract relevant standard errors and covariance for eu_position_cmc and interaction term
se_eu_position <- sqrt(vcov_matrix["eu_position", "eu_position"])
se_interaction <- sqrt(vcov_matrix["environment_onlyyes:eu_position", "environment_onlyyes:eu_position"])
cov_eu_position_interaction <- vcov_matrix["eu_position", "environment_onlyyes:eu_position"]

# Standard error of the combined effect
se_diff <- sqrt(se_eu_position^2 + se_interaction^2 + 2 * cov_eu_position_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

#YES FINAL VOTE & NOT ENVIRONMENT ----
# Define the extreme values for eu_position (eu_position_ep7_non_environment)
eu_position_quartiles <- mean_quartiles(ep7_mlr_sample$eu_position)
eu_position_ep7_environment_extreme_values <- data.frame(
  eu_position = eu_position_quartiles,
  environment_only = "no", # or other relevant value
  final_vote = "1", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  lrecon = mean(ep7_mlr_sample$lrecon),
  galtan = mean(ep7_mlr_sample$galtan)
)

# Generate predicted probabilities
predictions <- predict(eu_position_glmmtmb_sample, newdata = eu_position_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[1] - predictions[2]

# Generate the summary
summary_glmmtmb <- summary(eu_position_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond

se_eu_position_cmc <- fixed_effects["eu_position", "Std. Error"]
se_interaction_cmc <- fixed_effects["environment_onlyyes:eu_position", "Std. Error"]

# Extract covariance from the variance-covariance matrix
vcov_matrix <- vcov(eu_position_glmmtmb_sample)$cond
cov_eu_position_interaction <- vcov_matrix["eu_position", "environment_onlyyes:eu_position"]

# Corrected standard error of the difference
se_diff <- sqrt(se_eu_position_cmc^2 + se_interaction_cmc^2 + 2 * cov_eu_position_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

#NO FINAL VOTE & ENVIRONMENT ONLY ----
mean_quartiles <- function(x) {
  sorted_x <- sort(x)
  n <- length(sorted_x)
  lower_10_mean <- mean(sorted_x[1:floor(n * 0.10)])
  upper_10_mean <- mean(sorted_x[ceiling(n * 0.90):n])
  return(c(lower_10_mean, upper_10_mean))
}

# Define the extreme values for eu_position (eu_position_ep7_environment)
eu_position_quartiles <- mean_quartiles(ep7_mlr_sample$eu_position)
eu_position_ep7_environment_extreme_values <- data.frame(
  eu_position = eu_position_quartiles,
  environment_only = "yes", # or other relevant value
  final_vote = "0", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  lrecon = mean(ep7_mlr_sample$lrecon),
  galtan = mean(ep7_mlr_sample$galtan)
)

# Generate predicted probabilities
predictions <- predict(eu_position_glmmtmb_sample, newdata = eu_position_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[1] - predictions[2]

# Generate the summary
summary_glmmtmb <- summary(eu_position_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond
se_eu_position <- fixed_effects["eu_position", "Std. Error"]

# Extract the variance-covariance matrix
vcov_matrix <- vcov(eu_position_glmmtmb_sample)$cond

# Extract relevant standard errors and covariance for eu_position_cmc and interaction term
se_eu_position <- sqrt(vcov_matrix["eu_position", "eu_position"])
se_interaction <- sqrt(vcov_matrix["environment_onlyyes:eu_position", "environment_onlyyes:eu_position"])
cov_eu_position_interaction <- vcov_matrix["eu_position", "environment_onlyyes:eu_position"]

# Standard error of the combined effect
se_diff <- sqrt(se_eu_position^2 + se_interaction^2 + 2 * cov_eu_position_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

#NO FINAL VOTE & NOT ENVIRONMENT ----
# Define the extreme values for eu_position (eu_position_ep7_non_environment)
eu_position_quartiles <- mean_quartiles(ep7_mlr_sample$eu_position)
eu_position_ep7_environment_extreme_values <- data.frame(
  eu_position = eu_position_quartiles,
  environment_only = "no", # or other relevant value
  final_vote = "0", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  lrecon = mean(ep7_mlr_sample$lrecon),
  galtan = mean(ep7_mlr_sample$galtan)
)

# Generate predicted probabilities
predictions <- predict(eu_position_glmmtmb_sample, newdata = eu_position_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[1] - predictions[2]

# Generate the summary
summary_glmmtmb <- summary(eu_position_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond

se_eu_position_cmc <- fixed_effects["eu_position", "Std. Error"]
se_interaction_cmc <- fixed_effects["environment_onlyyes:eu_position", "Std. Error"]

# Extract covariance from the variance-covariance matrix
vcov_matrix <- vcov(eu_position_glmmtmb_sample)$cond
cov_eu_position_interaction <- vcov_matrix["eu_position", "environment_onlyyes:eu_position"]

# Corrected standard error of the difference
se_diff <- sqrt(se_eu_position_cmc^2 + se_interaction_cmc^2 + 2 * cov_eu_position_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")
# 1% mean ----
#YES FINAL VOTE & ENVIRONMENT ONLY ----
mean_quartiles <- function(x) {
  sorted_x <- sort(x)
  n <- length(sorted_x)
  lower_1_mean <- mean(sorted_x[1:floor(n * 0.01)])
  upper_99_mean <- mean(sorted_x[ceiling(n * 0.99):n])
  return(c(lower_1_mean, upper_99_mean))
}

# Define the extreme values for eu_position (eu_position_ep7_environment)
eu_position_quartiles <- mean_quartiles(ep7_mlr_sample$eu_position)
eu_position_ep7_environment_extreme_values <- data.frame(
  eu_position = eu_position_quartiles,
  environment_only = "yes", # or other relevant value
  final_vote = "1", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  lrecon = mean(ep7_mlr_sample$lrecon),
  galtan = mean(ep7_mlr_sample$galtan)
)

# Generate predicted probabilities
predictions <- predict(eu_position_glmmtmb_sample, newdata = eu_position_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[1] - predictions[2]

# Generate the summary
summary_glmmtmb <- summary(eu_position_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond
se_eu_position <- fixed_effects["eu_position", "Std. Error"]

# Extract the variance-covariance matrix
vcov_matrix <- vcov(eu_position_glmmtmb_sample)$cond

# Extract relevant standard errors and covariance for eu_position_cmc and interaction term
se_eu_position <- sqrt(vcov_matrix["eu_position", "eu_position"])
se_interaction <- sqrt(vcov_matrix["environment_onlyyes:eu_position", "environment_onlyyes:eu_position"])
cov_eu_position_interaction <- vcov_matrix["eu_position", "environment_onlyyes:eu_position"]

# Standard error of the combined effect
se_diff <- sqrt(se_eu_position^2 + se_interaction^2 + 2 * cov_eu_position_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

#YES FINAL VOTE & NOT ENVIRONMENT ----
# Define the extreme values for eu_position (eu_position_ep7_non_environment)
eu_position_quartiles <- mean_quartiles(ep7_mlr_sample$eu_position)
eu_position_ep7_environment_extreme_values <- data.frame(
  eu_position = eu_position_quartiles,
  environment_only = "no", # or other relevant value
  final_vote = "1", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  lrecon = mean(ep7_mlr_sample$lrecon),
  galtan = mean(ep7_mlr_sample$galtan)
)

# Generate predicted probabilities
predictions <- predict(eu_position_glmmtmb_sample, newdata = eu_position_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[1] - predictions[2]

# Generate the summary
summary_glmmtmb <- summary(eu_position_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond

se_eu_position_cmc <- fixed_effects["eu_position", "Std. Error"]
se_interaction_cmc <- fixed_effects["environment_onlyyes:eu_position", "Std. Error"]

# Extract covariance from the variance-covariance matrix
vcov_matrix <- vcov(eu_position_glmmtmb_sample)$cond
cov_eu_position_interaction <- vcov_matrix["eu_position", "environment_onlyyes:eu_position"]

# Corrected standard error of the difference
se_diff <- sqrt(se_eu_position_cmc^2 + se_interaction_cmc^2 + 2 * cov_eu_position_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

#NO FINAL VOTE & ENVIRONMENT ONLY ----
mean_quartiles <- function(x) {
  sorted_x <- sort(x)
  n <- length(sorted_x)
  lower_1_mean <- mean(sorted_x[1:floor(n * 0.01)])
  upper_99_mean <- mean(sorted_x[ceiling(n * 0.99):n])
  return(c(lower_1_mean, upper_99_mean))
}

# Define the extreme values for eu_position (eu_position_ep7_environment)
eu_position_quartiles <- mean_quartiles(ep7_mlr_sample$eu_position)
eu_position_ep7_environment_extreme_values <- data.frame(
  eu_position = eu_position_quartiles,
  environment_only = "yes", # or other relevant value
  final_vote = "0", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  lrecon = mean(ep7_mlr_sample$lrecon),
  galtan = mean(ep7_mlr_sample$galtan)
)

# Generate predicted probabilities
predictions <- predict(eu_position_glmmtmb_sample, newdata = eu_position_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[1] - predictions[2]

# Generate the summary
summary_glmmtmb <- summary(eu_position_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond
se_eu_position <- fixed_effects["eu_position", "Std. Error"]

# Extract the variance-covariance matrix
vcov_matrix <- vcov(eu_position_glmmtmb_sample)$cond

# Extract relevant standard errors and covariance for eu_position_cmc and interaction term
se_eu_position <- sqrt(vcov_matrix["eu_position", "eu_position"])
se_interaction <- sqrt(vcov_matrix["environment_onlyyes:eu_position", "environment_onlyyes:eu_position"])
cov_eu_position_interaction <- vcov_matrix["eu_position", "environment_onlyyes:eu_position"]

# Standard error of the combined effect
se_diff <- sqrt(se_eu_position^2 + se_interaction^2 + 2 * cov_eu_position_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

#NO FINAL VOTE & NOT ENVIRONMENT ----
# Define the extreme values for eu_position (eu_position_ep7_non_environment)
eu_position_quartiles <- mean_quartiles(ep7_mlr_sample$eu_position)
eu_position_ep7_environment_extreme_values <- data.frame(
  eu_position = eu_position_quartiles,
  environment_only = "no", # or other relevant value
  final_vote = "0", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  lrecon = mean(ep7_mlr_sample$lrecon),
  galtan = mean(ep7_mlr_sample$galtan)
)

# Generate predicted probabilities
predictions <- predict(eu_position_glmmtmb_sample, newdata = eu_position_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[1] - predictions[2]

# Generate the summary
summary_glmmtmb <- summary(eu_position_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond

se_eu_position_cmc <- fixed_effects["eu_position", "Std. Error"]
se_interaction_cmc <- fixed_effects["environment_onlyyes:eu_position", "Std. Error"]

# Extract covariance from the variance-covariance matrix
vcov_matrix <- vcov(eu_position_glmmtmb_sample)$cond
cov_eu_position_interaction <- vcov_matrix["eu_position", "environment_onlyyes:eu_position"]

# Corrected standard error of the difference
se_diff <- sqrt(se_eu_position_cmc^2 + se_interaction_cmc^2 + 2 * cov_eu_position_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

# Model galtan ----
# Fit the model on the stratified sample
galtan_glmmtmb_sample <- glmmTMB(true_vote_galtan ~ 
                                   lrecon * (environment_only + final_vote) +
                                   eu_position * (environment_only + final_vote) +
                                   galtan * (environment_only + final_vote) +
                                   lrecon * environment_only +
                                   eu_position * environment_only +
                                   galtan * environment_only +
                                   (1 | MEP.ID) +
                                   (1 | vote_id),
                                 data = ep7_mlr_sample,
                                 family = binomial())

check_collinearity(eu_position_glmmtmb_sample)

# 10% mean ----
#YES FINAL VOTE & ENVIRONMENT ONLY ----
mean_quartiles <- function(x) {
  sorted_x <- sort(x)
  n <- length(sorted_x)
  lower_10_mean <- mean(sorted_x[1:floor(n * 0.10)])
  upper_10_mean <- mean(sorted_x[ceiling(n * 0.90):n])
  return(c(lower_10_mean, upper_10_mean))
}

# Define the extreme values for galtan (galtan_ep7_environment)
galtan_quartiles <- mean_quartiles(ep7_mlr_sample$galtan)
galtan_ep7_environment_extreme_values <- data.frame(
  galtan = galtan_quartiles,
  environment_only = "yes", # or other relevant value
  final_vote = "1", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  lrecon = mean(ep7_mlr_sample$lrecon),
  eu_position = mean(ep7_mlr_sample$eu_position)
)

# Generate predicted probabilities
predictions <- predict(galtan_glmmtmb_sample, newdata = galtan_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[2] - predictions[1]

# Generate the summary
summary_glmmtmb <- summary(galtan_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond
se_eu_position <- fixed_effects["galtan", "Std. Error"]

# Extract the variance-covariance matrix
vcov_matrix <- vcov(galtan_glmmtmb_sample)$cond

# Extract relevant standard errors and covariance for galtan and interaction term
se_galtan <- sqrt(vcov_matrix["galtan", "galtan"])
se_interaction <- sqrt(vcov_matrix["environment_onlyyes:galtan", "environment_onlyyes:galtan"])
cov_galtan_interaction <- vcov_matrix["galtan", "environment_onlyyes:galtan"]

# Standard error of the combined effect
se_diff <- sqrt(se_galtan^2 + se_interaction^2 + 2 * cov_galtan_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

#YES FINAL VOTE & NOT ENVIRONMENT ----
# Define the extreme values for galtan (galtan_ep7_non_environment)
galtan_quartiles <- mean_quartiles(ep7_mlr_sample$galtan)
galtan_ep7_environment_extreme_values <- data.frame(
  galtan = galtan_quartiles,
  environment_only = "no", # or other relevant value
  final_vote = "1", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  lrecon = mean(ep7_mlr_sample$lrecon),
  eu_position = mean(ep7_mlr_sample$eu_position)
)

# Generate predicted probabilities
predictions <- predict(galtan_glmmtmb_sample, newdata = galtan_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[2] - predictions[1]

# Generate the summary
summary_glmmtmb <- summary(galtan_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond

se_galtan_cmc <- fixed_effects["galtan", "Std. Error"]
se_interaction_cmc <- fixed_effects["environment_onlyyes:galtan", "Std. Error"]

# Extract covariance from the variance-covariance matrix
vcov_matrix <- vcov(galtan_glmmtmb_sample)$cond
cov_galtan_interaction <- vcov_matrix["galtan", "environment_onlyyes:galtan"]

# Corrected standard error of the difference
se_diff <- sqrt(se_galtan_cmc^2 + se_interaction_cmc^2 + 2 * cov_galtan_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

#NO FINAL VOTE & ENVIRONMENT ONLY ----
mean_quartiles <- function(x) {
  sorted_x <- sort(x)
  n <- length(sorted_x)
  lower_10_mean <- mean(sorted_x[1:floor(n * 0.10)])
  upper_10_mean <- mean(sorted_x[ceiling(n * 0.90):n])
  return(c(lower_10_mean, upper_10_mean))
}

# Define the extreme values for galtan (galtan_ep7_environment)
galtan_quartiles <- mean_quartiles(ep7_mlr_sample$galtan)
galtan_ep7_environment_extreme_values <- data.frame(
  galtan = galtan_quartiles,
  environment_only = "yes", # or other relevant value
  final_vote = "0", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  lrecon = mean(ep7_mlr_sample$lrecon),
  eu_position = mean(ep7_mlr_sample$eu_position)
)

# Generate predicted probabilities
predictions <- predict(galtan_glmmtmb_sample, newdata = galtan_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[2] - predictions[1]

# Generate the summary
summary_glmmtmb <- summary(galtan_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond
se_eu_position <- fixed_effects["galtan", "Std. Error"]

# Extract the variance-covariance matrix
vcov_matrix <- vcov(galtan_glmmtmb_sample)$cond

# Extract relevant standard errors and covariance for galtan and interaction term
se_galtan <- sqrt(vcov_matrix["galtan", "galtan"])
se_interaction <- sqrt(vcov_matrix["environment_onlyyes:galtan", "environment_onlyyes:galtan"])
cov_galtan_interaction <- vcov_matrix["galtan", "environment_onlyyes:galtan"]

# Standard error of the combined effect
se_diff <- sqrt(se_galtan^2 + se_interaction^2 + 2 * cov_galtan_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

#NO FINAL VOTE & NOT ENVIRONMENT ----
# Define the extreme values for galtan (galtan_ep7_non_environment)
galtan_quartiles <- mean_quartiles(ep7_mlr_sample$galtan)
galtan_ep7_environment_extreme_values <- data.frame(
  galtan = galtan_quartiles,
  environment_only = "no", # or other relevant value
  final_vote = "0", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  lrecon = mean(ep7_mlr_sample$lrecon),
  eu_position = mean(ep7_mlr_sample$eu_position)
)

# Generate predicted probabilities
predictions <- predict(galtan_glmmtmb_sample, newdata = galtan_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[2] - predictions[1]

# Generate the summary
summary_glmmtmb <- summary(galtan_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond

se_galtan_cmc <- fixed_effects["galtan", "Std. Error"]
se_interaction_cmc <- fixed_effects["environment_onlyyes:galtan", "Std. Error"]

# Extract covariance from the variance-covariance matrix
vcov_matrix <- vcov(galtan_glmmtmb_sample)$cond
cov_galtan_interaction <- vcov_matrix["galtan", "environment_onlyyes:galtan"]

# Corrected standard error of the difference
se_diff <- sqrt(se_galtan_cmc^2 + se_interaction_cmc^2 + 2 * cov_galtan_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")
# 1% mean ----
#YES FINAL VOTE & ENVIRONMENT ONLY ----
mean_quartiles <- function(x) {
  sorted_x <- sort(x)
  n <- length(sorted_x)
  lower_1_mean <- mean(sorted_x[1:floor(n * 0.01)])
  upper_99_mean <- mean(sorted_x[ceiling(n * 0.99):n])
  return(c(lower_1_mean, upper_99_mean))
}

# Define the extreme values for galtan (galtan_ep7_environment)
galtan_quartiles <- mean_quartiles(ep7_mlr_sample$galtan)
galtan_ep7_environment_extreme_values <- data.frame(
  galtan = galtan_quartiles,
  environment_only = "yes", # or other relevant value
  final_vote = "1", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  lrecon = mean(ep7_mlr_sample$lrecon),
  eu_position = mean(ep7_mlr_sample$eu_position)
)

# Generate predicted probabilities
predictions <- predict(galtan_glmmtmb_sample, newdata = galtan_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[2] - predictions[1]

# Generate the summary
summary_glmmtmb <- summary(galtan_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond
se_eu_position <- fixed_effects["galtan", "Std. Error"]

# Extract the variance-covariance matrix
vcov_matrix <- vcov(galtan_glmmtmb_sample)$cond

# Extract relevant standard errors and covariance for galtan and interaction term
se_galtan <- sqrt(vcov_matrix["galtan", "galtan"])
se_interaction <- sqrt(vcov_matrix["environment_onlyyes:galtan", "environment_onlyyes:galtan"])
cov_galtan_interaction <- vcov_matrix["galtan", "environment_onlyyes:galtan"]

# Standard error of the combined effect
se_diff <- sqrt(se_galtan^2 + se_interaction^2 + 2 * cov_galtan_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

#YES FINAL VOTE & NOT ENVIRONMENT ----
# Define the extreme values for galtan (galtan_ep7_non_environment)
galtan_quartiles <- mean_quartiles(ep7_mlr_sample$galtan)
galtan_ep7_environment_extreme_values <- data.frame(
  galtan = galtan_quartiles,
  environment_only = "no", # or other relevant value
  final_vote = "1", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  lrecon = mean(ep7_mlr_sample$lrecon),
  eu_position = mean(ep7_mlr_sample$eu_position)
)

# Generate predicted probabilities
predictions <- predict(galtan_glmmtmb_sample, newdata = galtan_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[2] - predictions[1]

# Generate the summary
summary_glmmtmb <- summary(galtan_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond

se_galtan_cmc <- fixed_effects["galtan", "Std. Error"]
se_interaction_cmc <- fixed_effects["environment_onlyyes:galtan", "Std. Error"]

# Extract covariance from the variance-covariance matrix
vcov_matrix <- vcov(galtan_glmmtmb_sample)$cond
cov_galtan_interaction <- vcov_matrix["galtan", "environment_onlyyes:galtan"]

# Corrected standard error of the difference
se_diff <- sqrt(se_galtan_cmc^2 + se_interaction_cmc^2 + 2 * cov_galtan_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

#NO FINAL VOTE & ENVIRONMENT ONLY ----
mean_quartiles <- function(x) {
  sorted_x <- sort(x)
  n <- length(sorted_x)
  lower_1_mean <- mean(sorted_x[1:floor(n * 0.01)])
  upper_99_mean <- mean(sorted_x[ceiling(n * 0.99):n])
  return(c(lower_1_mean, upper_99_mean))
}

# Define the extreme values for galtan (galtan_ep7_environment)
galtan_quartiles <- mean_quartiles(ep7_mlr_sample$galtan)
galtan_ep7_environment_extreme_values <- data.frame(
  galtan = galtan_quartiles,
  environment_only = "yes", # or other relevant value
  final_vote = "0", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  lrecon = mean(ep7_mlr_sample$lrecon),
  eu_position = mean(ep7_mlr_sample$eu_position)
)

# Generate predicted probabilities
predictions <- predict(galtan_glmmtmb_sample, newdata = galtan_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[2] - predictions[1]

# Generate the summary
summary_glmmtmb <- summary(galtan_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond
se_eu_position <- fixed_effects["galtan", "Std. Error"]

# Extract the variance-covariance matrix
vcov_matrix <- vcov(galtan_glmmtmb_sample)$cond

# Extract relevant standard errors and covariance for galtan and interaction term
se_galtan <- sqrt(vcov_matrix["galtan", "galtan"])
se_interaction <- sqrt(vcov_matrix["environment_onlyyes:galtan", "environment_onlyyes:galtan"])
cov_galtan_interaction <- vcov_matrix["galtan", "environment_onlyyes:galtan"]

# Standard error of the combined effect
se_diff <- sqrt(se_galtan^2 + se_interaction^2 + 2 * cov_galtan_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

#NO FINAL VOTE & NOT ENVIRONMENT ----
# Define the extreme values for galtan (galtan_ep7_non_environment)
galtan_quartiles <- mean_quartiles(ep7_mlr_sample$galtan)
galtan_ep7_environment_extreme_values <- data.frame(
  galtan = galtan_quartiles,
  environment_only = "no", # or other relevant value
  final_vote = "0", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  lrecon = mean(ep7_mlr_sample$lrecon),
  eu_position = mean(ep7_mlr_sample$eu_position)
)

# Generate predicted probabilities
predictions <- predict(galtan_glmmtmb_sample, newdata = galtan_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[2] - predictions[1]

# Generate the summary
summary_glmmtmb <- summary(galtan_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond

se_galtan_cmc <- fixed_effects["galtan", "Std. Error"]
se_interaction_cmc <- fixed_effects["environment_onlyyes:galtan", "Std. Error"]

# Extract covariance from the variance-covariance matrix
vcov_matrix <- vcov(galtan_glmmtmb_sample)$cond
cov_galtan_interaction <- vcov_matrix["galtan", "environment_onlyyes:galtan"]

# Corrected standard error of the difference
se_diff <- sqrt(se_galtan_cmc^2 + se_interaction_cmc^2 + 2 * cov_galtan_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

# Model lrecon ----
# Fit the model on the stratified sample
lrecon_glmmtmb_sample <- glmmTMB(true_vote_lrecon ~ 
                                   lrecon * (environment_only + final_vote) +
                                   eu_position * (environment_only + final_vote) +
                                   galtan * (environment_only + final_vote) +
                                   lrecon * environment_only +
                                   eu_position * environment_only +
                                   galtan * environment_only +
                                   (1 | MEP.ID) +
                                   (1 | vote_id),
                                 data = ep7_mlr_sample,
                                 family = binomial())

check_collinearity(lrecon_glmmtmb_sample)

# 10% mean ----
#YES FINAL VOTE & ENVIRONMENT ONLY ----
mean_quartiles <- function(x) {
  sorted_x <- sort(x)
  n <- length(sorted_x)
  lower_10_mean <- mean(sorted_x[1:floor(n * 0.10)])
  upper_10_mean <- mean(sorted_x[ceiling(n * 0.90):n])
  return(c(lower_10_mean, upper_10_mean))
}

# Define the extreme values for lrecon (lrecon_ep7_environment)
lrecon_quartiles <- mean_quartiles(ep7_mlr_sample$lrecon)
lrecon_ep7_environment_extreme_values <- data.frame(
  lrecon = lrecon_quartiles,
  environment_only = "yes", # or other relevant value
  final_vote = "1", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  galtan = mean(ep7_mlr_sample$galtan),
  eu_position = mean(ep7_mlr_sample$eu_position)
)

# Generate predicted probabilities
predictions <- predict(lrecon_glmmtmb_sample, newdata = lrecon_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[2] - predictions[1]

# Generate the summary
summary_glmmtmb <- summary(lrecon_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond
se_lrecon <- fixed_effects["lrecon", "Std. Error"]

# Extract the variance-covariance matrix
vcov_matrix <- vcov(lrecon_glmmtmb_sample)$cond

# Extract relevant standard errors and covariance for lrecon and interaction term
se_lrecon <- sqrt(vcov_matrix["lrecon", "lrecon"])
se_interaction <- sqrt(vcov_matrix["lrecon:environment_onlyyes", "lrecon:environment_onlyyes"])
cov_lrecon_interaction <- vcov_matrix["lrecon", "lrecon:environment_onlyyes"]

# Standard error of the combined effect
se_diff <- sqrt(se_lrecon^2 + se_interaction^2 + 2 * cov_lrecon_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

#YES FINAL VOTE & NOT ENVIRONMENT ----
# Define the extreme values for lrecon (lrecon_ep7_environment)
lrecon_quartiles <- mean_quartiles(ep7_mlr_sample$lrecon)
lrecon_ep7_environment_extreme_values <- data.frame(
  lrecon = lrecon_quartiles,
  environment_only = "no", # or other relevant value
  final_vote = "1", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  galtan = mean(ep7_mlr_sample$galtan),
  eu_position = mean(ep7_mlr_sample$eu_position)
)

# Generate predicted probabilities
predictions <- predict(lrecon_glmmtmb_sample, newdata = lrecon_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[2] - predictions[1]

# Generate the summary
summary_glmmtmb <- summary(lrecon_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond

se_lrecon_cmc <- fixed_effects["lrecon", "Std. Error"]
se_interaction_cmc <- fixed_effects["lrecon:environment_onlyyes", "Std. Error"]

# Extract covariance from the variance-covariance matrix
vcov_matrix <- vcov(lrecon_glmmtmb_sample)$cond
cov_lrecon_interaction <- vcov_matrix["lrecon", "lrecon:environment_onlyyes"]

# Corrected standard error of the difference
se_diff <- sqrt(se_lrecon_cmc^2 + se_interaction_cmc^2 + 2 * cov_lrecon_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

#NO FINAL VOTE & ENVIRONMENT ONLY ----
mean_quartiles <- function(x) {
  sorted_x <- sort(x)
  n <- length(sorted_x)
  lower_10_mean <- mean(sorted_x[1:floor(n * 0.10)])
  upper_10_mean <- mean(sorted_x[ceiling(n * 0.90):n])
  return(c(lower_10_mean, upper_10_mean))
}

# Define the extreme values for lrecon (lrecon_ep7_environment)
lrecon_quartiles <- mean_quartiles(ep7_mlr_sample$lrecon)
lrecon_ep7_environment_extreme_values <- data.frame(
  lrecon = lrecon_quartiles,
  environment_only = "yes", # or other relevant value
  final_vote = "0", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  galtan = mean(ep7_mlr_sample$galtan),
  eu_position = mean(ep7_mlr_sample$eu_position)
)

# Generate predicted probabilities
predictions <- predict(lrecon_glmmtmb_sample, newdata = lrecon_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[2] - predictions[1]

# Generate the summary
summary_glmmtmb <- summary(lrecon_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond
se_lrecon <- fixed_effects["lrecon", "Std. Error"]

# Extract the variance-covariance matrix
vcov_matrix <- vcov(lrecon_glmmtmb_sample)$cond

# Extract relevant standard errors and covariance for lrecon and interaction term
se_lrecon <- sqrt(vcov_matrix["lrecon", "lrecon"])
se_interaction <- sqrt(vcov_matrix["lrecon:environment_onlyyes", "lrecon:environment_onlyyes"])
cov_lrecon_interaction <- vcov_matrix["lrecon", "lrecon:environment_onlyyes"]

# Standard error of the combined effect
se_diff <- sqrt(se_lrecon^2 + se_interaction^2 + 2 * cov_lrecon_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

#NO FINAL VOTE & NOT ENVIRONMENT ----
# Define the extreme values for lrecon (lrecon_ep7_environment)
lrecon_quartiles <- mean_quartiles(ep7_mlr_sample$lrecon)
lrecon_ep7_environment_extreme_values <- data.frame(
  lrecon = lrecon_quartiles,
  environment_only = "no", # or other relevant value
  final_vote = "0", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  galtan = mean(ep7_mlr_sample$galtan),
  eu_position = mean(ep7_mlr_sample$eu_position)
)

# Generate predicted probabilities
predictions <- predict(lrecon_glmmtmb_sample, newdata = lrecon_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[2] - predictions[1]

# Generate the summary
summary_glmmtmb <- summary(lrecon_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond

se_lrecon_cmc <- fixed_effects["lrecon", "Std. Error"]
se_interaction_cmc <- fixed_effects["lrecon:environment_onlyyes", "Std. Error"]

# Extract covariance from the variance-covariance matrix
vcov_matrix <- vcov(lrecon_glmmtmb_sample)$cond
cov_lrecon_interaction <- vcov_matrix["lrecon", "lrecon:environment_onlyyes"]

# Corrected standard error of the difference
se_diff <- sqrt(se_lrecon_cmc^2 + se_interaction_cmc^2 + 2 * cov_lrecon_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

# 1% mean ----
#YES FINAL VOTE & ENVIRONMENT ONLY ----
mean_quartiles <- function(x) {
  sorted_x <- sort(x)
  n <- length(sorted_x)
  lower_1_mean <- mean(sorted_x[1:floor(n * 0.01)])
  upper_99_mean <- mean(sorted_x[ceiling(n * 0.99):n])
  return(c(lower_1_mean, upper_99_mean))
}

# Define the extreme values for lrecon (lrecon_ep7_environment)
lrecon_quartiles <- mean_quartiles(ep7_mlr_sample$lrecon)
lrecon_ep7_environment_extreme_values <- data.frame(
  lrecon = lrecon_quartiles,
  environment_only = "yes", # or other relevant value
  final_vote = "1", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  galtan = mean(ep7_mlr_sample$galtan),
  eu_position = mean(ep7_mlr_sample$eu_position)
)

# Generate predicted probabilities
predictions <- predict(lrecon_glmmtmb_sample, newdata = lrecon_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[2] - predictions[1]

# Generate the summary
summary_glmmtmb <- summary(lrecon_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond
se_lrecon <- fixed_effects["lrecon", "Std. Error"]

# Extract the variance-covariance matrix
vcov_matrix <- vcov(lrecon_glmmtmb_sample)$cond

# Extract relevant standard errors and covariance for lrecon and interaction term
se_lrecon <- sqrt(vcov_matrix["lrecon", "lrecon"])
se_interaction <- sqrt(vcov_matrix["lrecon:environment_onlyyes", "lrecon:environment_onlyyes"])
cov_lrecon_interaction <- vcov_matrix["lrecon", "lrecon:environment_onlyyes"]

# Standard error of the combined effect
se_diff <- sqrt(se_lrecon^2 + se_interaction^2 + 2 * cov_lrecon_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

#YES FINAL VOTE & NOT ENVIRONMENT ----
# Define the extreme values for lrecon (lrecon_ep7_environment)
lrecon_quartiles <- mean_quartiles(ep7_mlr_sample$lrecon)
lrecon_ep7_environment_extreme_values <- data.frame(
  lrecon = lrecon_quartiles,
  environment_only = "no", # or other relevant value
  final_vote = "1", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  galtan = mean(ep7_mlr_sample$galtan),
  eu_position = mean(ep7_mlr_sample$eu_position)
)

# Generate predicted probabilities
predictions <- predict(lrecon_glmmtmb_sample, newdata = lrecon_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[2] - predictions[1]

# Generate the summary
summary_glmmtmb <- summary(lrecon_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond

se_lrecon_cmc <- fixed_effects["lrecon", "Std. Error"]
se_interaction_cmc <- fixed_effects["lrecon:environment_onlyyes", "Std. Error"]

# Extract covariance from the variance-covariance matrix
vcov_matrix <- vcov(lrecon_glmmtmb_sample)$cond
cov_lrecon_interaction <- vcov_matrix["lrecon", "lrecon:environment_onlyyes"]

# Corrected standard error of the difference
se_diff <- sqrt(se_lrecon_cmc^2 + se_interaction_cmc^2 + 2 * cov_lrecon_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

#NO FINAL VOTE & ENVIRONMENT ONLY ----
mean_quartiles <- function(x) {
  sorted_x <- sort(x)
  n <- length(sorted_x)
  lower_1_mean <- mean(sorted_x[1:floor(n * 0.01)])
  upper_99_mean <- mean(sorted_x[ceiling(n * 0.99):n])
  return(c(lower_1_mean, upper_99_mean))
}

# Define the extreme values for lrecon (lrecon_ep7_environment)
lrecon_quartiles <- mean_quartiles(ep7_mlr_sample$lrecon)
lrecon_ep7_environment_extreme_values <- data.frame(
  lrecon = lrecon_quartiles,
  environment_only = "yes", # or other relevant value
  final_vote = "0", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  galtan = mean(ep7_mlr_sample$galtan),
  eu_position = mean(ep7_mlr_sample$eu_position)
)

# Generate predicted probabilities
predictions <- predict(lrecon_glmmtmb_sample, newdata = lrecon_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[2] - predictions[1]

# Generate the summary
summary_glmmtmb <- summary(lrecon_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond
se_lrecon <- fixed_effects["lrecon", "Std. Error"]

# Extract the variance-covariance matrix
vcov_matrix <- vcov(lrecon_glmmtmb_sample)$cond

# Extract relevant standard errors and covariance for lrecon and interaction term
se_lrecon <- sqrt(vcov_matrix["lrecon", "lrecon"])
se_interaction <- sqrt(vcov_matrix["lrecon:environment_onlyyes", "lrecon:environment_onlyyes"])
cov_lrecon_interaction <- vcov_matrix["lrecon", "lrecon:environment_onlyyes"]

# Standard error of the combined effect
se_diff <- sqrt(se_lrecon^2 + se_interaction^2 + 2 * cov_lrecon_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")

#NO FINAL VOTE & NOT ENVIRONMENT ----
# Define the extreme values for lrecon (lrecon_ep7_environment)
lrecon_quartiles <- mean_quartiles(ep7_mlr_sample$lrecon)
lrecon_ep7_environment_extreme_values <- data.frame(
  lrecon = lrecon_quartiles,
  environment_only = "no", # or other relevant value
  final_vote = "0", # or other relevant value
  MEP.ID = NA, # setting random effects to zero
  vote_id = NA,
  galtan = mean(ep7_mlr_sample$galtan),
  eu_position = mean(ep7_mlr_sample$eu_position)
)

# Generate predicted probabilities
predictions <- predict(lrecon_glmmtmb_sample, newdata = lrecon_ep7_environment_extreme_values, type = "response")

# Calculate the difference in predicted probabilities
diff_predicted_probs <- predictions[2] - predictions[1]

# Generate the summary
summary_glmmtmb <- summary(lrecon_glmmtmb_sample)

# Extract the fixed effects and their standard errors
fixed_effects <- summary_glmmtmb$coefficients$cond

se_lrecon_cmc <- fixed_effects["lrecon", "Std. Error"]
se_interaction_cmc <- fixed_effects["lrecon:environment_onlyyes", "Std. Error"]

# Extract covariance from the variance-covariance matrix
vcov_matrix <- vcov(lrecon_glmmtmb_sample)$cond
cov_lrecon_interaction <- vcov_matrix["lrecon", "lrecon:environment_onlyyes"]

# Corrected standard error of the difference
se_diff <- sqrt(se_lrecon_cmc^2 + se_interaction_cmc^2 + 2 * cov_lrecon_interaction)

# Calculate the z-score and p-value
z_score <- diff_predicted_probs / se_diff
p_value <- 2 * pnorm(-abs(z_score))

# Calculate the 95% confidence interval
z_critical <- 1.96  # 95% confidence level
ci_lower <- diff_predicted_probs - z_critical * se_diff
ci_upper <- diff_predicted_probs + z_critical * se_diff

# Print the results
cat("Difference in predicted probabilities:", diff_predicted_probs, "\n")
cat("Standard error of the difference:", se_diff, "\n")
cat("Z-score:", z_score, "\n")
cat("P-value:", p_value, "\n")
cat("95% Confidence Interval: [", ci_lower, ",", ci_upper, "]\n")
